# Makerlab Return Processor — v1.0.6.1-test

**Date:** November 20, 2026  
**Baseline:** v1.0.6-test application, with v1.0.5.3-test `odoo.py`  
**Changed:** `odoo.py` only

## Issue fixed

Odoo `TC/IN/12521` belongs to Helpdesk #03795. The first `Validate` resulted in a **Zero Demand Warning**. After confirming **Keep lines**, the original code waited for warehouse approval and failed if none was visible, even though Odoo still displayed an actionable `Validate`. The user's second captured HTML shows that a further Validate created four **Grant Approval** planned activities. The app previously prohibited all further clicks in this situation.

## New two-stage validation rule — New stock only

1. Verify exact transfer ID, target SKU quantities, and every extra zero-demand row. Click **Keep lines** on the verified dialog.
2. Record `zero_demand_keep_lines_confirmed=True` in the existing restore checkpoint.
3. Give Odoo time to show the real warehouse handoff. Check pending planned activities, not stock state or Validate avatar.
4. If no approval and no error or open dialog exists, verify the **same TC/IN**, exact SKU Demand, and selected `MNL/Stock` / `BLC/Stock` destination.
5. Save `post_keep_lines_second_validate_in_flight=True` *before* a single additional Validate click.
6. Continue after a real warehouse **Grant Approval** or warehouse-specific To Do appears. Persist `validated=False` and `warehouse_approval_requested=True` / `warehouse_todo_created=True` as appropriate. Do not wait for Done and do not grant approval on behalf of the warehouse.
7. If the second click remains uncertain, stop. No third Validate, no duplicate Return, no accidental Lark filing.

## Recovery

- An upgraded checkpoint saved after Keep lines but before the second click can safely resume the guarded second stage using the **existing TC/IN**.
- Any checkpoint indicating that the second click was attempted cannot auto-click again.
- Older checkpoints that did not record a positive Keep lines confirmation remain Manual Review; the application cannot infer proof from Draft/Ready/Done or from the user's screenshot alone.
- Save-point failures prevent the second click from being sent.

## Unchanged

- Existing Sales Order/Delivery, blank-delivery transfer population, multiple classification groups, per-item Demand, Zero Demand Keep lines, QC for Defective/Unsealed, configurable New-stock MNL/BLC destination, Wrong Item/Scam route, manual Odoo-to-Lark reconciliation, and Lark filing.

## Test results

- **12 offline Playwright/pytest checks passed** using the November 20 HTML captures and simulated Odoo events. Includes two-step Validate; confirmed Keep lines recovery state; existing Grant Approval bypass; mismatched Demand block; missing approval block; no-warning single-click behavior; failure to persist second-click checkpoint.
- **12 existing v1.0.6 Wrong Item/Scam regression checks passed** (application import and Lark workflow compatibility), using the updated Odoo module.
- `odoo.py` compiles.

**No live Odoo or Lark submissions were performed.**
