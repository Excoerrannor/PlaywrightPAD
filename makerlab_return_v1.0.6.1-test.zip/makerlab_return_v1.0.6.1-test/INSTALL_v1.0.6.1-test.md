# Makerlab Return Processor v1.0.6.1-test — Installation

**Baseline:** Makerlab Return Processor v1.0.6-test (Wrong Item/Scam workflow), using the Odoo module from v1.0.5.3-test.

This release changes **only `odoo.py`**. Do not replace `main.py`, `lark.py`, `wrong_item_lark.py`, `workflow_store.py`, `history_window.py`, `ui_theme.py`, marketplace modules, `OdooProfile`, or `data`.

1. Close the running Return Processor so `odoo.py` is not in use.
2. Back up `C:\PlaywrightPAD\odoo.py` to a safe filename and back up `C:\PlaywrightPAD\data` before testing.
3. Copy the supplied `odoo.py` into `C:\PlaywrightPAD\odoo.py`.
4. Start the application normally. Test with a controlled New-stock return that has unrelated zero-demand lines.
5. Check that the exact SKU/quantity and destination are correct, and that a warehouse **Grant Approval** or specifically assigned warehouse **To Do** appears. Do not treat the stock status (Draft/Ready/Done) or Studio approval avatar as evidence.

## New workflow

For New-stock returns only:

- First Validate click.
- If Odoo displays **Zero Demand Warning**, the existing routine verifies the exact TC/IN, intended SKU Demand, and unrelated zero-demand rows, then clicks **Keep lines** (never Remove lines).
- The application durably saves `zero_demand_keep_lines_confirmed` in the existing recovery checkpoint.
- If no real warehouse handoff appears after the short settle period, it rechecks the transfer ID, saved Demand, destination, absence of any blocking dialog/error, then durably saves `post_keep_lines_second_validate_in_flight` and clicks Validate **one additional time**.
- It waits for actual pending warehouse Grant Approval or a verified warehouse To Do. This is the success signal; reaching Done is not required.
- If approval is still absent, the action is uncertain, or the second Validate produces another unresolved confirmation, processing stops in Manual Review. The system does not attempt a third Validate.

Normal returns without the zero-demand warning keep the previous single Validate behavior. Defective and Unsealed QC processing is unchanged.

## Existing TC/IN/12521

The supplied after-state HTML shows four pending **Grant Approval** activities for this TC/IN; if that is still the live Odoo state, **do not click Validate again**. Reconcile the existing record using Recovery or the manual TC/IN-to-Lark path.

**Older checkpoints** generated before v1.0.6.1 do not contain a durable `zero_demand_keep_lines_confirmed` marker. If a previous Validate has an uncertain outcome, the processor will NOT automatically click it again. Inspect the TC/IN in Odoo, finish the remaining step manually if appropriate, then use the existing manual Odoo reconciliation / Lark-only filing path. Never create another Helpdesk ticket or Return for the same recorded TC/IN.

## Offline test

The archive includes `test_post_keep_lines_validate.py` and two user-supplied HTML fixture captures. Tests require `pytest`, `beautifulsoup4`, `playwright`, and a compatible installed Chromium browser. Run `python -m pytest -q test_post_keep_lines_validate.py` from the extracted folder if those prerequisites are present. The tests do not connect to Odoo.

**Live Odoo verification has not been performed.**
