"""Offline regression tests for post-Keep-lines New-stock Validate behavior.

Uses the two Odoo HTML captures provided November 20, 2026; no Odoo writes.
"""
from pathlib import Path
import importlib.util
import re
import pytest
from bs4 import BeautifulSoup
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parent
CAPTURE_BEFORE = ROOT / 'fixtures' / 'odoo_before_warehouse_approval.html'
CAPTURE_AFTER = ROOT / 'fixtures' / 'odoo_after_warehouse_approval.html'

spec = importlib.util.spec_from_file_location('odoo_v1061', ROOT / 'odoo.py')
odoo = importlib.util.module_from_spec(spec)
spec.loader.exec_module(odoo)

@pytest.fixture(scope='module')
def captured_html():
    before = CAPTURE_BEFORE.read_text(encoding='utf-8')
    after = CAPTURE_AFTER.read_text(encoding='utf-8')
    approvals = BeautifulSoup(after, 'html.parser').select_one('.o-mail-ActivityList')
    assert approvals is not None
    return before, str(approvals)

@pytest.fixture()
def browser_page(monkeypatch, captured_html):
    with sync_playwright() as p:
        kwargs = {
            'headless': True,
            'args': ['--no-sandbox', '--disable-gpu', '--disable-dev-shm-usage'],
        }
        if Path('/usr/bin/chromium').is_file():
            kwargs['executable_path'] = '/usr/bin/chromium'
        browser = p.chromium.launch(**kwargs)
        page = browser.new_page()
        page.set_content(captured_html[0], wait_until='domcontentloaded')
        # Odoo reactive form input value is not serialized in the captured HTML.
        page.locator('div[name="location_dest_id"] input').evaluate(
            "el => {el.value='MNL/Stock'; el.setAttribute('value','MNL/Stock')}"
        )
        wait_original = odoo._wait_for_new_stock_handoff
        def short_wait(page, transfer_id, timeout_ms=25_000, **kwargs):
            return wait_original(page, transfer_id, min(timeout_ms, 700), **kwargs)
        monkeypatch.setattr(odoo, '_wait_for_new_stock_handoff', short_wait)
        yield page
        browser.close()


def _install_events(page, approvals, *, first_warning=False, approval_on_second=True):
    page.evaluate('''({approvals, firstWarning, approvalOnSecond}) => {
        window.validates = 0;
        window.keepClicks = 0;
        document.body.insertAdjacentHTML('beforeend',
          '<div role="option" style="display:block" id="dest-choice">MNL/Stock</div>');
        let button = document.querySelector('button[name="button_validate"]');
        if (!button) throw new Error('Captured page missing Validate button');
        button.addEventListener('click', () => {
            window.validates += 1;
            if (firstWarning && window.validates === 1) {
                document.body.insertAdjacentHTML('beforeend',
                    '<div role="dialog" class="modal d-block" style="position:fixed;left:30%;top:20%;width:400px;height:200px;background:white;z-index:9999">'
                  + '<div class="modal-content"><h4 class="modal-title">Zero Demand Warning</h4>'
                  + '<button name="process" type="object" class="btn">Keep lines</button>'
                  + '<button name="process_without_zero_moves">Remove lines</button></div></div>');
            } else if ((firstWarning && window.validates === 2) ||
                       (!firstWarning && window.validates === 1 && approvalOnSecond)) {
                if (approvalOnSecond) document.body.insertAdjacentHTML('beforeend', approvals);
            }
        });
        document.addEventListener('click', event => {
            if (event.target.closest('button[name="process"]')) {
                window.keepClicks += 1;
                document.querySelector('div[role="dialog"]')?.remove();
            }
        });
    }''', {'approvals': approvals, 'firstWarning': first_warning,
          'approvalOnSecond': approval_on_second})


def _items():
    return [{'sku': 'MLE00714', 'quantity': 4}]


def test_capture_before_and_after(captured_html):
    before, approvals = captured_html
    before_soup = BeautifulSoup(before, 'html.parser')
    assert before_soup.select_one('button[name="button_validate"]') is not None
    assert not before_soup.select('.o-mail-ActivityList .o-mail-Activity')
    after_soup = BeautifulSoup(approvals, 'html.parser')
    assert len(after_soup.select('.o-mail-Activity')) == 4
    assert all('Grant Approval' in a.get_text(' ', strip=True)
               for a in after_soup.select('.o-mail-Activity'))
    rows = before_soup.select('div[name="move_ids"] tr.o_data_row')
    assert len(rows) == 5
    quantities = [r.select_one('td[name="product_uom_qty"]').get_text(strip=True)
                  for r in rows]
    assert quantities == ['0.00','0.00','0.00','0.00','4.00']


def test_warehouse_signal_is_not_statusbar(browser_page, captured_html):
    page = browser_page
    assert odoo._warehouse_handoff_activity(page) is None
    # Validate button's waiting-approval avatar is NOT sufficient.
    assert page.locator('button[name="button_validate"] img[title="Waiting for approval"]').count()
    page.locator('body').evaluate('(body, html) => body.insertAdjacentHTML("beforeend", html)', captured_html[1])
    assert odoo._warehouse_handoff_activity(page)['kind'] == 'grant_approval'


def test_saved_keep_lines_allows_one_more_validate(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=False)
    sent = []
    result = odoo._process_brand_new(
        page, items=_items(), destination='MNL/Stock',
        resume_after_keep_lines=True, before_second_validate=lambda: sent.append('saved')
    )
    assert sent == ['saved']
    assert page.evaluate('window.validates') == 1
    assert result['warehouse_approval_requested'] is True
    assert result['validated'] is False
    assert result['warehouse_handoff_complete'] is True


def test_first_validate_warning_keep_second_validate(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=True)
    calls = []
    result = odoo._process_brand_new(
        page, items=_items(), destination='MNL/Stock',
        before_validate=lambda: calls.append('first saved'),
        on_keep_lines=lambda: calls.append('keep saved'),
        before_second_validate=lambda: calls.append('second saved'),
    )
    assert calls == ['first saved', 'keep saved', 'second saved']
    assert page.evaluate('window.validates') == 2
    assert page.evaluate('window.keepClicks') == 1
    assert result['warehouse_approval_requested'] is True
    assert not result['validated']


def test_wrong_demand_blocks_second_validate(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1])
    page.locator('div[name="move_ids"] tr.o_data_row').last.locator('td[name="product_uom_qty"]').evaluate(
        "cell => cell.textContent = '5.00'"
    )
    calls = []
    with pytest.raises(RuntimeError, match='Unsafe Odoo Demand'):
        odoo._process_brand_new(
            page, items=_items(), resume_after_keep_lines=True,
            before_second_validate=lambda: calls.append('second'),
        )
    assert page.evaluate('window.validates') == 0
    assert not calls


def test_second_attempt_without_approval_stops_after_two(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=True, approval_on_second=False)
    calls = []
    with pytest.raises(RuntimeError, match='neither a pending Grant Approval'):
        odoo._process_brand_new(
            page, items=_items(), destination='MNL/Stock',
            before_validate=lambda: calls.append('first'),
            on_keep_lines=lambda: calls.append('kept'),
            before_second_validate=lambda: calls.append('second'),
        )
    assert calls == ['first', 'kept', 'second']
    assert page.evaluate('window.validates') == 2
    assert page.evaluate('window.keepClicks') == 1


def test_second_attempt_requires_durable_checkpoint(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=False)
    with pytest.raises(RuntimeError, match='durable second-click checkpoint'):
        odoo._process_brand_new(page, items=_items(), resume_after_keep_lines=True)
    assert page.evaluate('window.validates') == 0


def test_no_keep_lines_no_approval_never_retries(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=False, approval_on_second=False)
    # First click performs no action in this synthetic scenario.
    calls = []
    with pytest.raises(RuntimeError, match='neither a pending Grant Approval'):
        odoo._process_brand_new(
            page, items=_items(), destination='MNL/Stock',
            before_validate=lambda: calls.append('first'),
            before_second_validate=lambda: calls.append('second')
        )
    assert calls == ['first']
    assert page.evaluate('window.validates') == 1


def test_existing_pending_grant_approval_skips_validate(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=False)
    page.locator('body').evaluate('(body, html) => body.insertAdjacentHTML("beforeend", html)', captured_html[1])
    result=odoo._process_brand_new(page, items=_items(), destination='MNL/Stock',
                                  resume_after_keep_lines=True,
                                  before_second_validate=lambda: (_ for _ in ()).throw(AssertionError('must not click')))
    assert result['warehouse_approval_requested'] is True
    assert page.evaluate('window.validates') == 0


def test_recovery_marker_guards_present():
    source=(ROOT/'odoo.py').read_text()
    assert "pending.get('post_keep_lines_second_validate_in_flight')" in source
    assert "pending.get('zero_demand_keep_lines_confirmed')" in source
    assert 'before_second_validate()' in source
    assert "checkpoint['stage'] = 'return_post_keep_lines_second_validate_in_flight'" in source


def test_fresh_processing_persists_boundaries_before_clicks(browser_page, captured_html, monkeypatch):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=True)
    values = []
    def fake_open_transfer(page, order_id, items, before_create, on_transfer_created,
                           platform):
        before_create()
        on_transfer_created({
            'transfer_id': 'TC/IN/12521',
            'transfer_url': 'https://makerlab.odoo.com/odoo/helpdesk/3/tickets/3795/stock.picking/807053',
            'delivery_to_return': 'BLC/OUT/274201',
            'manual_stock_entry_required': False,
        })
    monkeypatch.setattr(odoo, '_open_return_transfer', fake_open_transfer)
    group_items = [{'sku':'MLE00714','quantity':4,'classification':'New',
                   'decision':'Refunded','status':'Returned'}]
    cp = odoo._base_checkpoint(
        order_id='2611110XAXXJ', ticket_title='test',
        ticket_url='https://makerlab.odoo.com/odoo/helpdesk/3/tickets/3795',
        first_sku='MLE00714', tags=[], platform='Shopee'
    )
    cp['setup_complete'] = True
    def record(checkpoint,event):
        import copy
        values.append((event,copy.deepcopy(checkpoint)))
    output=odoo._process_return_groups(
        page,'2611110XAXXJ',group_items,cp,checkpoint_callback=record
    )
    marker_events=[v for e,v in values if v.get('pending_return')]
    keep_positions=[i for i,x in enumerate(marker_events)
                    if x['pending_return'].get('zero_demand_keep_lines_confirmed')
                    and not x['pending_return'].get('post_keep_lines_second_validate_in_flight')]
    second_positions=[i for i,x in enumerate(marker_events)
                      if x['pending_return'].get('post_keep_lines_second_validate_in_flight')]
    assert keep_positions and second_positions and min(keep_positions)<min(second_positions)
    assert all(x['resume_safe'] is False for x in marker_events)
    assert cp['pending_warehouse_approval_transfer_ids']==['TC/IN/12521']
    assert cp['next_return_index'] is None  # Completed group finalized the case.
    assert cp.get('pending_return') is None
    assert output['returns'][0]['warehouse_handoff_complete'] is True
    assert page.evaluate('window.validates') == 2


def test_checkpoint_persistence_failure_blocks_second_click(browser_page, captured_html):
    page = browser_page
    _install_events(page, captured_html[1], first_warning=True)
    with pytest.raises(RuntimeError,match='disk write failure'):
        odoo._process_brand_new(
            page, items=_items(), destination='MNL/Stock',
            before_validate=lambda: None,
            on_keep_lines=lambda: None,
            before_second_validate=lambda: (_ for _ in ()).throw(
                RuntimeError('disk write failure')),
        )
    assert page.evaluate('window.validates') == 1
    assert page.evaluate('window.keepClicks') == 1
