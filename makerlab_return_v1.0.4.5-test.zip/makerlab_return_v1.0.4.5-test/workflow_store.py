import copy
import json
import os
import shutil
import sys
import uuid
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path

SCHEMA_VERSION = 1
# Approved, exact Odoo location names. Do not accept arbitrary freeform paths.
NEW_STOCK_DESTINATIONS = ("MNL/Stock", "BLC/Stock")
DEFAULT_NEW_STOCK_DESTINATION = "MNL/Stock"


def normalize_new_stock_destination(value, *, default=DEFAULT_NEW_STOCK_DESTINATION):
    """Validate a destination. Invalid settings never change the stock route."""
    if value in NEW_STOCK_DESTINATIONS:
        return value
    if default in NEW_STOCK_DESTINATIONS:
        return default
    raise ValueError(f"Unsupported Brand New destination: {value!r}")

# Odoo/Lark-linked history records are protected from accidental deletion.
# The processor checks active and archived history for recorded tickets. Only
# the separately-confirmed permanent local delete may remove this guard.
PROTECTED_WORKFLOW_STATES = frozenset({
    "odoo_ticket_created", "odoo_ticket_setup_pending", "odoo_ticket_ready",
    "odoo_return_pending", "odoo_error_manual_review", "manual_review",
    "lark_pending", "completed",
})

EDITABLE_ITEM_FIELDS = frozenset({
    "sku", "quantity", "amount", "classification", "decision", "status",
    "grade", "odoo_tag", "remarks",
})


def has_external_work(*records):
    """Conservatively detect whether deletion or editing could hide Odoo/Lark work."""
    for record in records:
        if not isinstance(record, dict):
            continue
        if (record.get("odoo_checkpoint") or record.get("odoo_results")
                or record.get("lark_results")):
            return True
        if record.get("workflow_state") in PROTECTED_WORKFLOW_STATES:
            return True
        # Older checkpoints may be nested in a restore point.
        if record.get("pending_return") or record.get("ticket_url"):
            return True
    return False


MANILA_TZ = timezone(timedelta(hours=8))


def _now_iso():
    return datetime.now(MANILA_TZ).isoformat(timespec="seconds")


def _json_safe(value):
    """Convert processor state into plain JSON-safe values."""
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, dict):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item) for item in value]
    return str(value)


def _default_data_dir():
    override = os.environ.get("MAKERLAB_RETURN_DATA_DIR", "").strip()
    if override:
        return Path(override).expanduser().resolve()

    if getattr(sys, "frozen", False):
        app_dir = Path(sys.executable).resolve().parent
    else:
        app_dir = Path(__file__).resolve().parent
    return app_dir / "data"


class WorkflowStore:
    """Atomic JSON persistence for scan history and unfinished workflows."""

    def __init__(self, data_dir=None):
        self.data_dir = Path(data_dir) if data_dir else _default_data_dir()
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.scan_history_path = self.data_dir / "scan_history.json"
        self.restore_points_path = self.data_dir / "restore_points.json"
        self.settings_path = self.data_dir / "settings.json"
        self.last_warning = ""

        self._ensure_file(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        self._ensure_file(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}},
        )
        self._ensure_file(self.settings_path, self._default_settings())

    @staticmethod
    def _blank_copy(value):
        return copy.deepcopy(value)

    def _ensure_file(self, path, default):
        if not path.exists():
            self._atomic_write(path, default, create_backup=False)
            return
        # Read once on startup so corruption is recovered immediately.
        self._read_json(path, default)

    def _read_json(self, path, default):
        try:
            with path.open("r", encoding="utf-8") as handle:
                value = json.load(handle)
            if not isinstance(value, dict):
                raise ValueError("JSON root must be an object")
            return value
        except Exception as error:
            backup_path = path.with_suffix(path.suffix + ".bak")
            if backup_path.exists():
                try:
                    with backup_path.open("r", encoding="utf-8") as handle:
                        value = json.load(handle)
                    if not isinstance(value, dict):
                        raise ValueError("backup JSON root must be an object")
                    self.last_warning = (
                        f"Recovered {path.name} from backup after read error: {error}"
                    )
                    self._atomic_write(path, value, create_backup=False)
                    return value
                except Exception:
                    pass

            timestamp = datetime.now(MANILA_TZ).strftime("%Y%m%d-%H%M%S")
            corrupt_path = path.with_name(f"{path.stem}.corrupt-{timestamp}{path.suffix}")
            try:
                if path.exists():
                    path.replace(corrupt_path)
            except Exception:
                pass
            self.last_warning = (
                f"Could not read {path.name}; a fresh file was created. "
                f"Original saved as {corrupt_path.name}. Error: {error}"
            )
            fresh = self._blank_copy(default)
            self._atomic_write(path, fresh, create_backup=False)
            return fresh

    def _atomic_write(self, path, value, create_backup=True):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = path.with_suffix(path.suffix + ".tmp")
        backup_path = path.with_suffix(path.suffix + ".bak")
        safe_value = _json_safe(value)

        if create_backup and path.exists():
            try:
                shutil.copy2(path, backup_path)
            except OSError:
                # Backup failure should not prevent the current state from saving.
                pass

        with temp_path.open("w", encoding="utf-8", newline="\n") as handle:
            json.dump(
                safe_value,
                handle,
                indent=2,
                ensure_ascii=False,
                sort_keys=False,
            )
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp_path, path)

    # ------------------------------------------------------------------
    # Persistent application settings (extendable without changing scan data)
    # ------------------------------------------------------------------
    @staticmethod
    def _default_settings():
        return {
            "schema_version": SCHEMA_VERSION,
            "new_stock_destination": DEFAULT_NEW_STOCK_DESTINATION,
        }

    def load_settings(self):
        data = self._read_json(self.settings_path, self._default_settings())
        destination = normalize_new_stock_destination(
            data.get("new_stock_destination"),
            default=DEFAULT_NEW_STOCK_DESTINATION,
        )
        return {**data, "new_stock_destination": destination}

    def save_settings(self, *, new_stock_destination):
        if new_stock_destination not in NEW_STOCK_DESTINATIONS:
            raise ValueError("Brand New destination must be MNL/Stock or BLC/Stock.")
        data = self.load_settings()
        data.update({
            "schema_version": SCHEMA_VERSION,
            "new_stock_destination": new_stock_destination,
        })
        self._atomic_write(self.settings_path, data)
        return self.load_settings()

    # ------------------------------------------------------------------
    # Scan history
    # ------------------------------------------------------------------
    def start_scan(
        self,
        *,
        platform,
        search_by,
        search_input,
        order_id,
        return_case,
        items,
        new_stock_destination=DEFAULT_NEW_STOCK_DESTINATION,
    ):
        data = self._read_json(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        scans = data.setdefault("scans", [])
        scan_id = uuid.uuid4().hex
        now = _now_iso()
        record = {
            "scan_id": scan_id,
            "created_at": now,
            "updated_at": now,
            "workflow_state": "loaded",
            "platform": str(platform or ""),
            "search_by": str(search_by or ""),
            "search_input": str(search_input or ""),
            "order_id": str(order_id or ""),
            "request_id": str((return_case or {}).get("request_id") or ""),
            "tracking_number": str(
                (return_case or {}).get("tracking_number") or ""
            ),
            "return_case": _json_safe(return_case or {}),
            "items": _json_safe(items or []),
            "case_decision": None,
            "new_stock_destination": normalize_new_stock_destination(
                new_stock_destination,
            ),
            "odoo_results": None,
            "odoo_checkpoint": None,
            "lark_results": [],
            "last_error": "",
            "completed_at": "",
        }
        scans.append(record)
        self._atomic_write(self.scan_history_path, data)
        return scan_id

    def update_scan(self, scan_id, *, workflow_state=None, **updates):
        if not scan_id:
            return None
        data = self._read_json(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        for record in data.setdefault("scans", []):
            if record.get("scan_id") != scan_id:
                continue
            if record.get("archived"):
                raise RuntimeError(
                    "This scan is archived and cannot be updated or submitted again."
                )
            if workflow_state:
                record["workflow_state"] = str(workflow_state)
            for key, value in updates.items():
                record[str(key)] = _json_safe(value)
            record["updated_at"] = _now_iso()
            if workflow_state == "completed":
                record["completed_at"] = record["updated_at"]
            self._atomic_write(self.scan_history_path, data)
            return copy.deepcopy(record)
        return None

    def get_scan(self, scan_id):
        data = self._read_json(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        for record in data.get("scans", []):
            if record.get("scan_id") == scan_id:
                return copy.deepcopy(record)
        return None

    def list_recent_scans(self, limit=50):
        """Return newest scans; limit=None returns the full history for the GUI."""
        data = self._read_json(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        scans = list(data.get("scans", []))
        scans.sort(key=lambda item: item.get("updated_at", ""), reverse=True)
        if limit is not None:
            scans = scans[: max(0, int(limit))]
        return copy.deepcopy(scans)

    # ------------------------------------------------------------------
    # Persistent restore points
    # ------------------------------------------------------------------
    def save_restore_point(self, scan_id, snapshot):
        if not scan_id:
            raise ValueError("scan_id is required to save a restore point")
        data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}},
        )
        # Archived history must never receive a fresh Recovery point, even
        # when an earlier processor instance still holds the old scan ID.
        existing_scan = self.get_scan(scan_id)
        if existing_scan and existing_scan.get("archived"):
            raise RuntimeError("Cannot restore an archived Odoo/Lark scan.")
        points = data.setdefault("restore_points", {})
        existing = points.get(scan_id, {})
        created_at = existing.get("created_at") or _now_iso()
        # Workflow snapshots are regenerated by main.py at each Odoo/Lark
        # milestone. Preserve operator edits that are local audit metadata,
        # rather than accidentally losing them during a normal checkpoint.
        history_metadata = self.get_scan(scan_id) or {}
        metadata = {}
        for field in ("operator_notes", "edit_history"):
            if field not in snapshot:
                if field in existing:
                    metadata[field] = copy.deepcopy(existing[field])
                elif field in history_metadata:
                    metadata[field] = copy.deepcopy(history_metadata[field])
        points[scan_id] = {
            "scan_id": scan_id,
            "created_at": created_at,
            "updated_at": _now_iso(),
            **metadata,
            **_json_safe(snapshot),
        }
        self._atomic_write(self.restore_points_path, data)
        return copy.deepcopy(points[scan_id])

    def delete_restore_point(self, scan_id):
        if not scan_id:
            return False
        data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}},
        )
        points = data.setdefault("restore_points", {})
        if scan_id not in points:
            return False
        points.pop(scan_id, None)
        self._atomic_write(self.restore_points_path, data)
        return True

    def get_restore_point(self, scan_id):
        data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}},
        )
        value = data.get("restore_points", {}).get(scan_id)
        if value and (value.get("archived") or
                      (self.get_scan(scan_id) or {}).get("archived")):
            return None
        return copy.deepcopy(value) if value else None

    def list_restore_points(self):
        data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}},
        )
        history = self._read_json(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        archived_ids = {
            record.get("scan_id") for record in history.get("scans", [])
            if record.get("archived")
        }
        points = [
            value for key, value in data.get("restore_points", {}).items()
            if key not in archived_ids and not value.get("archived")
        ]
        points.sort(key=lambda item: item.get("updated_at", ""), reverse=True)
        return copy.deepcopy(points)

    # ------------------------------------------------------------------
    # Operator changes to saved Scan History / Recovery
    # ------------------------------------------------------------------
    def edit_saved_record(self, scan_id, edits, *, expected_updated_at=None):
        """Edit a saved scan, also updating its authoritative recovery snapshot.

        Only identity/item data of NOT-YET-FILED scans may change. If Odoo or
        Lark work exists, edit ONLY operator_notes; never rewrite the actual
        submitted marketplace, ticket, SKU/quantity or Lark values.

        If there is an active recovery snapshot it is written FIRST, so a
        failure writing the history mirror cannot destroy safe recovery data.
        """
        scan_id = str(scan_id or "").strip()
        if not scan_id or not isinstance(edits, dict):
            raise ValueError("A valid scan ID and changes are required.")
        history_data = self._read_json(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        restore_data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}},
        )
        history_list = history_data.setdefault("scans", [])
        history = next((v for v in history_list if v.get("scan_id") == scan_id), None)
        points = restore_data.setdefault("restore_points", {})
        restore = points.get(scan_id)
        if history is None and restore is None:
            raise ValueError("This scan no longer exists in History or Recovery.")
        archived = any(v and v.get("archived") for v in (history, restore))
        if archived and set(edits) - {"operator_notes"}:
            raise ValueError("An archived scan permits internal audit notes only.")
        latest = restore if restore is not None else history
        if (expected_updated_at is not None and
                latest.get("updated_at") != expected_updated_at):
            raise RuntimeError(
                "This scan was changed since the editor opened. Refresh History "
                "and reopen Edit before saving."
            )
        locked = archived or has_external_work(history, restore)
        allowed = {"operator_notes"} if locked else {
            "operator_notes", "order_id", "search_by", "search_input",
            "tracking_number", "new_stock_destination", "items",
        }
        unknown = set(edits) - allowed
        if unknown:
            raise ValueError(
                "This case already has Odoo/Lark progress. Only internal notes "
                "can be edited; transactional data is locked."
                if locked else f"Unsupported edit fields: {', '.join(sorted(unknown))}"
            )
        if not edits:
            return copy.deepcopy(latest)

        clean = {}
        if "operator_notes" in edits:
            clean["operator_notes"] = str(edits["operator_notes"] or "").strip()[:5000]
        if not locked:
            if "order_id" in edits:
                clean["order_id"] = str(edits["order_id"] or "").strip()
                if not clean["order_id"]:
                    raise ValueError("Order ID cannot be blank.")
            if "search_by" in edits:
                clean["search_by"] = str(edits["search_by"] or "").strip()
                modes = {
                    "Shopee": {"Tracking Number", "Order ID", "Order Link"},
                    "Lazada": {"Tracking Number", "Order ID"},
                    "TikTok": {"Tracking Number", "Order ID", "Return Order ID"},
                }
                if clean["search_by"] not in modes.get(latest.get("platform"), set()):
                    raise ValueError("Invalid search mode for this marketplace.")
            for field in ("search_input", "tracking_number"):
                if field in edits:
                    clean[field] = str(edits[field] or "").strip()
            if "new_stock_destination" in edits:
                chosen = edits["new_stock_destination"]
                if chosen not in NEW_STOCK_DESTINATIONS:
                    raise ValueError("Warehouse must be MNL/Stock or BLC/Stock.")
                clean["new_stock_destination"] = chosen
            if "items" in edits:
                items = edits["items"]
                if not isinstance(items, list) or not items:
                    raise ValueError("At least one item must remain in a scan.")
                verified_items = []
                for index, raw_item in enumerate(items, start=1):
                    if not isinstance(raw_item, dict):
                        raise ValueError(f"Item {index} must be a record.")
                    item = copy.deepcopy(raw_item)
                    sku = str(item.get("sku") or "").strip().upper()
                    if not re.fullmatch(r"[A-Z0-9_+.-]+", sku):
                        raise ValueError(f"Invalid SKU in item {index}: {sku!r}.")
                    try:
                        qty = int(str(item.get("quantity", "")).strip())
                    except (ValueError, TypeError) as error:
                        raise ValueError(f"Item {index} must have a whole-number QTY.") from error
                    if qty < 1:
                        raise ValueError(f"Item {index} QTY must be at least 1.")
                    item["sku"] = sku
                    item["quantity"] = qty
                    amount = item.get("amount", "")
                    if str(amount).strip() == "":
                        if latest.get("platform") != "TikTok":
                            raise ValueError(f"Enter the Amount for {sku}.")
                        item["amount"] = ""
                    else:
                        try:
                            money = float(amount)
                        except (ValueError, TypeError) as error:
                            raise ValueError(f"Invalid Amount for {sku}.") from error
                        if not (0 <= money < float("inf")):
                            raise ValueError(f"Amount must be finite and nonnegative for {sku}.")
                        item["amount"] = round(money, 2)
                    for field in ("classification", "decision", "status", "grade", "odoo_tag", "remarks"):
                        item[field] = str(item.get(field) or "").strip()
                    # Unconfirmed, partially completed choices are allowed.
                    verified_items.append(item)
                clean["items"] = verified_items

        changed_fields = {
            field for field, value in clean.items()
            if latest.get(field, "") != value
        }
        if not changed_fields:
            return copy.deepcopy(latest)
        now = _now_iso()
        changes_log = {
            "at": now,
            "action": "operator_edit",
            "changed_fields": sorted(changed_fields),
            "protected": bool(locked),
        }
        # Draft changes invalidate the old confirmation so the user must review
        # all items again. A historical Odoo/Lark result is NEVER unconfirmed.
        unconfirm = bool(changed_fields - {"operator_notes"}) and not locked
        targets = [obj for obj in (history, restore) if obj is not None]
        for record in targets:
            record.update(copy.deepcopy(clean))
            if unconfirm:
                record["case_decision"] = None
                record["workflow_state"] = "manually_saved"
            if "order_id" in clean or "tracking_number" in clean:
                case = copy.deepcopy(record.get("return_case") or {})
                if "order_id" in clean:
                    case["order_id"] = clean["order_id"]
                if "tracking_number" in clean:
                    case["tracking_number"] = clean["tracking_number"]
                record["return_case"] = case
            record["updated_at"] = now
            record.setdefault("edit_history", []).append(changes_log)

        if restore is not None:
            self._atomic_write(self.restore_points_path, restore_data)
        if history is None:
            history_list.append(copy.deepcopy(restore))
        self._atomic_write(self.scan_history_path, history_data)
        saved = self.get_restore_point(scan_id) if restore is not None else self.get_scan(scan_id)
        if saved is None:
            raise RuntimeError("Edited scan could not be verified on disk.")
        return saved

    def delete_saved_record(self, scan_id):
        """Delete a draft scan, or safely archive one with Odoo/Lark evidence.

        Archived records are hidden from the History GUI but remain inside
        scan_history.json so the existing duplicate-ticket guard still sees
        their original Odoo ticket and transfer identifiers.
        """
        scan_id = str(scan_id or "").strip()
        if not scan_id:
            raise ValueError("Choose a scan to delete.")
        history_data = self._read_json(
            self.scan_history_path,
            {"schema_version": SCHEMA_VERSION, "scans": []},
        )
        restore_data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}},
        )
        history_list = history_data.setdefault("scans", [])
        history = next((v for v in history_list if v.get("scan_id") == scan_id), None)
        restore_points = restore_data.setdefault("restore_points", {})
        restore = restore_points.get(scan_id)
        if history is None and restore is None:
            raise ValueError("This scan has already been deleted.")
        if history and history.get("archived"):
            # A previous attempt may have saved the safe archive but failed
            # while removing Recovery. Reattempt the cleanup idempotently.
            if restore is not None:
                restore_points.pop(scan_id)
                self._atomic_write(self.restore_points_path, restore_data)
            return {"mode": "archived", "scan_id": scan_id}
        if restore and restore.get("archived"):
            raise ValueError("This scan is already archived.")

        if has_external_work(history, restore):
            # Backward compatibility: a processed "Delete" is archive, not
            # destruction of Odoo evidence. The GUI exposes Archive separately.
            return self.archive_saved_record(scan_id,
                                             reason="delete_requested_protected")

        # Unprocessed scans can be deleted entirely. Remove Recovery FIRST:
        # if the history write then fails, the history remains visible but an
        # incomplete case will never be offered as recoverable accidentally.
        if restore is not None:
            restore_points.pop(scan_id)
            self._atomic_write(self.restore_points_path, restore_data)
        if history is not None:
            history_data["scans"] = [
                record for record in history_list if record.get("scan_id") != scan_id
            ]
            self._atomic_write(self.scan_history_path, history_data)
        return {"mode": "deleted", "scan_id": scan_id}

    def permanently_delete_saved_record(
        self, scan_id, *, typed_order_id="", confirmation="",
        external_acknowledged=False,
    ):
        """Actually remove a scan from BOTH active JSON stores.

        Unlike Archive, this removes the LOCAL duplicate-ticket guard for this
        scan. It NEVER touches Odoo or Lark. Processed scans require an explicit
        operator confirmation; ordinary draft scans do not.

        Crash ordering is conservative: Recovery is removed first, so if the
        History write fails, the previous ticket is still visible and will
        continue blocking duplicate creation. JSON .bak files may retain prior
        copies; they are not active application records.
        """
        scan_id = str(scan_id or "").strip()
        if not scan_id:
            raise ValueError("Select a saved scan first.")
        history_data = self._read_json(
            self.scan_history_path, {"schema_version": SCHEMA_VERSION, "scans": []})
        restore_data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}})
        history_list = history_data.setdefault("scans", [])
        history = next((r for r in history_list if r.get("scan_id") == scan_id), None)
        restore = restore_data.setdefault("restore_points", {}).get(scan_id)
        if history is None and restore is None:
            raise ValueError("This local scan no longer exists.")
        protected = has_external_work(history, restore)
        record = restore or history
        if protected:
            order_id = str(record.get("order_id") or "").strip()
            if (not order_id or str(typed_order_id or "").strip() != order_id
                    or confirmation != "DELETE LOCAL RECORD"
                    or external_acknowledged is not True):
                raise PermissionError(
                    "A scan with Odoo/Lark work requires the exact Order ID, "
                    "DELETE LOCAL RECORD, and explicit acknowledgment that "
                    "external transactions are NOT deleted automatically."
                )
        old_restore = copy.deepcopy(restore_data)
        if restore is not None:
            restore_data["restore_points"].pop(scan_id, None)
            self._atomic_write(self.restore_points_path, restore_data)
        try:
            if history is not None:
                history_data["scans"] = [
                    r for r in history_list if r.get("scan_id") != scan_id
                ]
                self._atomic_write(self.scan_history_path, history_data)
        except Exception:
            # If possible, restore the recovery checkpoint, keeping the case
            # recoverable until the operator retries the deletion.
            if restore is not None:
                try:
                    self._atomic_write(self.restore_points_path, old_restore)
                except Exception as rollback_error:
                    raise RuntimeError(
                        "Local delete failed and recovery rollback also failed. "
                        "Restore from the JSON .bak files before resubmitting."
                    ) from rollback_error
            raise
        remaining_history = self._read_json(
            self.scan_history_path, {"schema_version": SCHEMA_VERSION, "scans": []})
        remaining_restore = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}})
        if (any(r.get("scan_id") == scan_id for r in remaining_history.get("scans", []))
                or scan_id in remaining_restore.get("restore_points", {})):
            raise RuntimeError("Local scan deletion could not be verified.")
        return {"mode": "deleted", "scan_id": scan_id,
                "had_external_work": protected}

    def reset_saved_scan_for_resubmission(
        self, scan_id, *, typed_order_id, confirmation,
        external_acknowledged=False,
    ):
        """Clear stale Odoo progress only after an explicit external review.

        Preserve marketplace data and per-item remarks, but require all item
        decisions to be re-confirmed. Cannot reset a case with recorded Lark
        results. The old ticket/transfer identifiers are retained ONLY as a
        local reset-audit event, not as an active Odoo checkpoint.
        """
        scan_id = str(scan_id or "").strip()
        history_data = self._read_json(
            self.scan_history_path, {"schema_version": SCHEMA_VERSION, "scans": []})
        restore_data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}})
        history = next((r for r in history_data.get("scans", [])
                        if r.get("scan_id") == scan_id), None)
        restore = restore_data.get("restore_points", {}).get(scan_id)
        if not history or not restore:
            raise ValueError("Select an active scan with a Recovery snapshot.")
        if history.get("archived") or restore.get("archived"):
            raise ValueError("Unarchive the record before resetting its Odoo work.")
        source = restore
        order_id = str(source.get("order_id") or "").strip()
        if (not order_id or str(typed_order_id or "").strip() != order_id
                or confirmation != "RESET ODOO"
                or external_acknowledged is not True):
            raise PermissionError(
                "Reset requires the exact Order ID and RESET ODOO after "
                "reviewing/deleting or cancelling the old Odoo transactions."
            )
        if (source.get("workflow_state") == "completed" or source.get("completed_at")
                or history.get("workflow_state") == "completed" or history.get("completed_at")):
            raise RuntimeError("Completed filings cannot be reset; inspect/delete instead.")
        if (str(history.get("order_id") or "").strip() != order_id
                or str(history.get("platform") or "").strip()
                != str(source.get("platform") or "").strip()):
            raise RuntimeError("History and Recovery do not match. Resolve JSON before reset.")
        if source.get("lark_results") or history.get("lark_results"):
            raise RuntimeError("This scan has Lark results. Reset is not allowed.")
        if not (source.get("odoo_checkpoint") or source.get("odoo_results")
                or history.get("odoo_checkpoint") or history.get("odoo_results")):
            raise ValueError("There is no recorded Odoo checkpoint to reset.")
        if not source.get("items") or not source.get("order_id"):
            raise ValueError("Cannot reset a scan without its original Order ID and items.")
        old_history = copy.deepcopy(history_data)
        now = _now_iso()
        checkpoint = source.get("odoo_checkpoint") or history.get("odoo_checkpoint") or {}
        results = source.get("odoo_results") or history.get("odoo_results") or {}
        transfers = []
        for group in list(checkpoint.get("returns") or []) + list(results.get("returns") or []):
            transfer_id = str(group.get("transfer_id") or "")
            if transfer_id and transfer_id not in transfers:
                transfers.append(transfer_id)
        pending = checkpoint.get("pending_return") or {}
        if pending.get("transfer_id") and pending["transfer_id"] not in transfers:
            transfers.append(pending["transfer_id"])
        audit = {
            "at": now,
            "action": "manual_odoo_cleanup_reset",
            "previous_ticket_title": str(checkpoint.get("ticket_title") or results.get("ticket_title") or ""),
            "previous_ticket_url": str(checkpoint.get("ticket_url") or results.get("ticket_url") or ""),
            "previous_transfer_ids": transfers,
            "acknowledgment": (
                "Operator reviewed prior Odoo ticket and inventory transfers "
                "and confirmed external cleanup before resubmission"
            ),
        }
        def cleared(record):
            record.update({
                "workflow_state": "manually_saved",
                "case_decision": None,
                "odoo_checkpoint": None,
                "odoo_results": None,
                "lark_results": [],
                "last_error": "",
                "completed_at": "",
                "transfer_display": "Not created yet",
                "updated_at": now,
            })
            record.setdefault("reset_history", []).append(copy.deepcopy(audit))
        # The restore point is the freshest source of item decisions/remarks.
        for field in ("items", "return_case", "new_stock_destination",
                      "platform", "search_by", "search_input", "order_id"):
            if field in source:
                history[field] = copy.deepcopy(source[field])
        cleared(history)
        new_restore = copy.deepcopy(source)
        cleared(new_restore)
        # History first: if the app crashes before writing Recovery, the OLD
        # Recovery checkpoint still blocks resubmitting the Odoo transaction.
        self._atomic_write(self.scan_history_path, history_data)
        try:
            restore_data["restore_points"][scan_id] = new_restore
            self._atomic_write(self.restore_points_path, restore_data)
        except Exception:
            try:
                self._atomic_write(self.scan_history_path, old_history)
            except Exception as rollback_error:
                raise RuntimeError(
                    "Reset failed and history rollback failed; reconcile the JSON "
                    "files from .bak before resubmitting."
                ) from rollback_error
            raise
        updated_scan = self.get_scan(scan_id)
        updated_restore = self.get_restore_point(scan_id)
        if (not updated_scan or not updated_restore
                or updated_scan.get("odoo_checkpoint")
                or updated_restore.get("odoo_checkpoint")
                or updated_restore.get("case_decision")
                or updated_scan.get("workflow_state") != "manually_saved"):
            raise RuntimeError("The Odoo reset could not be verified. Do not submit.")
        return {"mode": "reset_for_resubmission", "scan_id": scan_id,
                "prior_ticket_url": audit["previous_ticket_url"],
                "prior_transfer_ids": transfers}

    def find_prior_odoo_scans(self, platform, order_id, *, exclude_scan_id=None):
        """Return ALL earlier local Odoo records, including archived ones.

        Does not infer external status: it is a local duplicate-prevention guard.
        Recovery may be fresher than its history mirror; prefer it when present.
        """
        platform, order_id = str(platform or "").strip(), str(order_id or "").strip()
        history = self.list_recent_scans(limit=None)
        points = {v["scan_id"]: v for v in self.list_restore_points()}
        by_id = {v["scan_id"]: v for v in history if v.get("scan_id")}
        for scan_id, point in points.items():
            if scan_id not in by_id:
                by_id[scan_id] = point
        found = []
        for scan_id, history_row in by_id.items():
            if scan_id == exclude_scan_id:
                continue
            if history_row.get("platform") != platform or str(history_row.get("order_id") or "") != order_id:
                continue
            record = copy.deepcopy(history_row)
            if scan_id in points:
                point = points[scan_id]
                for field in ("odoo_checkpoint", "odoo_results", "lark_results",
                              "case_decision", "workflow_state", "items"):
                    if field in point:
                        record[field] = copy.deepcopy(point[field])
            if not (record.get("odoo_checkpoint") or record.get("odoo_results")):
                continue
            record["has_restore_point"] = scan_id in points
            found.append(record)
        found.sort(key=lambda r: (bool(r.get("has_restore_point")),
                                  str(r.get("updated_at") or "")), reverse=True)
        return found

    def archive_saved_record(self, scan_id, *, reason="operator_archived"):
        """Hide a scan without destroying Odoo evidence or losing its snapshot.

        Write the archived history record FIRST; remove Recovery only after
        the audit + original checkpoint have been durably saved.
        """
        scan_id = str(scan_id or "").strip()
        if not scan_id:
            raise ValueError("Choose a scan to archive.")
        history_data = self._read_json(
            self.scan_history_path, {"schema_version": SCHEMA_VERSION, "scans": []})
        restore_data = self._read_json(
            self.restore_points_path,
            {"schema_version": SCHEMA_VERSION, "restore_points": {}})
        scans = history_data.setdefault("scans", [])
        history = next((v for v in scans if v.get("scan_id") == scan_id), None)
        restore = restore_data.setdefault("restore_points", {}).get(scan_id)
        if history is None and restore is None:
            raise ValueError("Scan does not exist.")
        if history and history.get("archived"):
            if restore is not None:
                restore_data["restore_points"].pop(scan_id, None)
                self._atomic_write(self.restore_points_path, restore_data)
            return {"mode": "archived", "scan_id": scan_id}
        source = copy.deepcopy(history or restore)
        if restore is not None:
            # Recovery is the authoritative Odoo/Lark state if a prior history
            # write failed. Never replace newer external identifiers with an
            # older history mirror.
            for field in ("odoo_checkpoint", "odoo_results", "lark_results",
                          "case_decision", "workflow_state", "items",
                          "new_stock_destination", "return_case", "last_error"):
                if field in restore:
                    source[field] = copy.deepcopy(restore[field])
        snapshot = copy.deepcopy(restore or source)
        snapshot.pop("archived_restore_snapshot", None)
        source["archived_restore_snapshot"] = snapshot
        now = _now_iso()
        source.update({"archived": True, "archived_at": now,
                       "archived_reason": str(reason or "operator_archived"),
                       "updated_at": now})
        source.setdefault("edit_history", []).append(
            {"at": now, "action": "archive", "reason": source["archived_reason"]})
        if history is None:
            scans.append(source)
        else:
            history.clear()
            history.update(source)
        self._atomic_write(self.scan_history_path, history_data)
        if restore is not None:
            restore_data["restore_points"].pop(scan_id, None)
            self._atomic_write(self.restore_points_path, restore_data)
        return {"mode": "archived", "scan_id": scan_id}

    def reactivate_archived_record(self, scan_id):
        """Return an archived scan to History and, when safe, to Recovery.

        Any previously created Odoo ticket/TC/IN is REVIEW-ONLY on return.
        An archived external checkpoint is *never* made resume_safe=True.
        """
        scan_id = str(scan_id or "").strip()
        data = self._read_json(
            self.scan_history_path, {"schema_version": SCHEMA_VERSION, "scans": []})
        record = next((r for r in data.get("scans", [])
                       if r.get("scan_id") == scan_id), None)
        if record is None or not record.get("archived"):
            raise ValueError("Select an archived record.")
        original = copy.deepcopy(record.get("archived_restore_snapshot") or record)
        for key in ("archived", "archived_at", "archived_reason", "archived_restore_snapshot"):
            original.pop(key, None)
        old_state = str(original.get("workflow_state") or "loaded")
        is_completed = old_state == "completed" or bool(original.get("completed_at"))
        had_external = has_external_work(original)
        can_restore = bool(original.get("order_id") and original.get("items")) and not is_completed
        if had_external:
            checkpoint = original.get("odoo_checkpoint")
            if checkpoint:
                if not original.get("case_decision"):
                    can_restore = False
                else:
                    checkpoint = copy.deepcopy(checkpoint)
                    checkpoint["resume_safe"] = False
                    checkpoint["archived_original_stage"] = checkpoint.get("stage")
                    checkpoint["stage"] = "archived_manual_review"
                    original["odoo_checkpoint"] = checkpoint
                    original["workflow_state"] = "manual_review"
            elif original.get("odoo_results"):
                if not original.get("case_decision") or original.get("lark_results"):
                    can_restore = False
                else:
                    original["workflow_state"] = "lark_pending"
            else:
                can_restore = False
        now = _now_iso()
        record.pop("archived_restore_snapshot", None)
        record.pop("archived", None)
        record.pop("archived_at", None)
        record.pop("archived_reason", None)
        record["updated_at"] = now
        record.setdefault("edit_history", []).append(
            {"at": now, "action": "unarchive", "recovery_reopened": bool(can_restore)})
        if can_restore:
            record["workflow_state"] = original.get("workflow_state", old_state)
            if had_external and original.get("odoo_checkpoint"):
                record["odoo_checkpoint"] = copy.deepcopy(original["odoo_checkpoint"])
        self._atomic_write(self.scan_history_path, data)
        if can_restore:
            original["updated_at"] = now
            original["edit_history"] = copy.deepcopy(record.get("edit_history") or [])
            self.save_restore_point(scan_id, original)
            verified = self.get_restore_point(scan_id)
            if not verified or verified.get("order_id") != record.get("order_id"):
                raise RuntimeError("Reopened Recovery snapshot could not be verified.")
        return {"mode": "unarchived", "scan_id": scan_id,
                "recoverable": bool(can_restore),
                "review_only": bool(had_external)}

    def record_duplicate_override(self, scan_id, *, prior_scan_id,
                                  typed_order_id, reason, confirmation):
        """Write an auditable one-off operator exception BEFORE Odoo submission.

        This does not remove the earlier duplicate evidence and does not turn
        off the duplicate guard for later attempts. A fresh confirmation is
        required each time another Helpdesk ticket is about to be created.
        """
        reason = str(reason or "").strip()
        if len(reason) < 15:
            raise ValueError("Describe why a separate ticket is required (15+ characters).")
        if str(confirmation or "").strip() != "CREATE SEPARATE TICKET":
            raise ValueError("Type CREATE SEPARATE TICKET to confirm the exception.")
        data = self._read_json(
            self.scan_history_path, {"schema_version": SCHEMA_VERSION, "scans": []})
        records = {r.get("scan_id"): r for r in data.get("scans", [])}
        current = records.get(scan_id)
        previous = records.get(prior_scan_id)
        if not current or current.get("archived") or not previous or prior_scan_id == scan_id:
            raise ValueError("Both the new scan and previous recorded case are required.")
        if current.get("odoo_checkpoint") or current.get("odoo_results") or current.get("lark_results"):
            raise RuntimeError("This scan already has Odoo/Lark work; cannot override.")
        if (current.get("platform") != previous.get("platform") or
            current.get("order_id") != previous.get("order_id") or
            str(typed_order_id or "").strip() != str(current.get("order_id") or "")):
            raise ValueError("The exact marketplace Order ID must match both saved scans.")
        prior = previous.get("odoo_checkpoint") or previous.get("odoo_results") or {}
        if not (previous.get("odoo_checkpoint") or previous.get("odoo_results")):
            raise ValueError("The earlier Odoo ticket must be present in local audit records.")
        now = _now_iso()
        event = {
            "at": now, "action": "separate_odoo_ticket_operator_exception",
            "prior_scan_id": prior_scan_id,
            "prior_ticket_title": str(prior.get("ticket_title") or ""),
            "prior_ticket_url": str(prior.get("ticket_url") or ""),
            "reason": reason,
            "verified_order_id": str(typed_order_id).strip(),
            "attestation": "Operator inspected existing Odoo case and confirmed a distinct return",
        }
        current.setdefault("duplicate_override_events", []).append(event)
        current["updated_at"] = now
        self._atomic_write(self.scan_history_path, data)
        saved = self.get_scan(scan_id)
        if not saved or event not in saved.get("duplicate_override_events", []):
            raise RuntimeError("Duplicate exception audit could not be verified.")
        return copy.deepcopy(event)

    @property
    def paths(self):
        return {
            "data_dir": str(self.data_dir),
            "scan_history": str(self.scan_history_path),
            "restore_points": str(self.restore_points_path),
            "settings": str(self.settings_path),
        }
